(() => {
 'use strict';
 const api='https://polytrack-tas-leaderboard.polytrackispeak.workers.dev';
 Object.defineProperty(window,'__TAS_SERVER_URL',{value:api});
 Object.defineProperty(window,'__TAS_BUILD_ID',{value:'4ff3f96a5a9bff1dcffbc3f1583fc65bbb8a65f4f0a499172f6b865d98ba950d'});
 window.polytrackModConfiguration={modName:'TAS Tool',author:'zeptjan'};
 const storage=window.localStorage,prefix='tas-tool-063:';
 const keys=()=>Object.keys(storage).filter(k=>k.startsWith(prefix)).map(k=>k.slice(prefix.length));
 const methods={getItem:k=>storage.getItem(prefix+k),setItem:(k,v)=>storage.setItem(prefix+k,String(v)),removeItem:k=>storage.removeItem(prefix+k),clear:()=>keys().forEach(k=>storage.removeItem(prefix+k)),key:i=>keys()[i]??null};
 window.__tasStorage=new Proxy({}, {get(t,k){if(k==='length')return keys().length;if(k in methods)return methods[k];return typeof k==='string'?methods.getItem(k):undefined},set(t,k,v){methods.setItem(k,v);return true},ownKeys:()=>keys(),getOwnPropertyDescriptor(t,k){return keys().includes(k)?{enumerable:true,configurable:true,value:methods.getItem(k)}:undefined}});
 function allowed(url,method='GET'){
  try{const u=new URL(url,location.href),m=method.toUpperCase();if(u.username||u.password)return false;
   if(u.origin===location.origin)return m==='GET'||m==='HEAD';
   if(u.protocol==='blob:'||u.protocol==='data:')return m==='GET';
   if(u.origin===api)return (m==='GET'&&['/health','/leaderboard'].includes(u.pathname))||(m==='POST'&&['/submit','/recordings'].includes(u.pathname));
   return u.origin==='https://vps.kodub.com'&&(m==='GET'||m==='HEAD')&&!/^\/v6\/(leaderboard|recordings|verifyRecordings)(?:\/|$)/i.test(u.pathname);
  }catch{return false}
 }
 const nativeFetch=window.fetch.bind(window);
 window.fetch=(input,init)=>{const url=input instanceof Request?input.url:String(input),method=init?.method||(input instanceof Request?input.method:'GET');return allowed(url,method)?nativeFetch(input,init):Promise.reject(new TypeError('Request disabled in TAS Tool'))};
 const open=XMLHttpRequest.prototype.open,send=XMLHttpRequest.prototype.send,requests=new WeakMap;
 XMLHttpRequest.prototype.open=function(method,url,...args){requests.set(this,{method,url});return open.call(this,method,url,...args)};
 XMLHttpRequest.prototype.send=function(body){const r=requests.get(this);if(!r||!allowed(r.url,r.method))throw new DOMException('Request disabled in TAS Tool','SecurityError');return send.call(this,body)};
 Object.defineProperty(window,'WebSocket',{value:class{constructor(){throw new DOMException('Multiplayer is disabled in TAS Tool','SecurityError')}},configurable:false});
 if(navigator.sendBeacon)Object.defineProperty(navigator,'sendBeacon',{value:()=>false});
 addEventListener('DOMContentLoaded',()=>{
  const help=document.getElementById('tas-help-dialog');document.getElementById('tas-help').addEventListener('click',()=>help.showModal());
  const step=document.getElementById('tas-step');step.addEventListener('click',()=>{const runtime=window.__PTAS;if(runtime?.car){runtime.setPaused(true);runtime.step()}});
  setInterval(()=>{step.disabled=!window.__PTAS?.car},500);
  const disableMultiplayer=()=>{for(const b of document.querySelectorAll('button'))if(b.textContent.trim()==='Multiplayer'){b.disabled=true;b.title='Multiplayer is unavailable in this TAS build'}};
  new MutationObserver(disableMultiplayer).observe(document.getElementById('ui'),{childList:true,subtree:true});disableMultiplayer();
  help.addEventListener('keydown',e=>e.stopPropagation());help.addEventListener('click',e=>{if(e.target===help)help.close()});
  addEventListener('keydown',e=>{if(help.open)e.stopImmediatePropagation()},true);
 });
})();
